//
//  TableViewAppDelegate.h
//  TableView
//
//  Created by nishi on 10/08/25.
//  Copyright TARGET ENTERTAINMENT INC. 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

